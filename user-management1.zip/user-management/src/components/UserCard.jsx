function UserCard({
  user,
  onSelectUser,
  onAddFavorite,
  onRemoveFavorite
}) {
  return (
    <div onClick={() => onSelectUser(user)}>
      <div>
        <h3>{user.name}</h3>
        <p>{user.email}</p>
       <button
  onClick={(e) => {
    e.stopPropagation()

    const isFavorite = false

    if (isFavorite) {
      onRemoveFavorite(user.id)
    } else {
      onAddFavorite(user)
    }
  }}
>
  ⭐ Favourite
</button>
      </div>
    </div>
  )
}

export default UserCard