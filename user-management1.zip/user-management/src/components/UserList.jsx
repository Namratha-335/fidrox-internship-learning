import UserCard from './UserCard'

function UserList({
  users,
  onSelectUser,
  onAddFavorite,
  onRemoveFavorite
}) {
  return (
    <div>
      {users.map(user => (
        <UserCard
            key={user.id}
            user={user}
            onSelectUser={onSelectUser}
            onAddFavorite={onAddFavorite}
            onRemoveFavorite={onRemoveFavorite}
            />
      ))}
    </div>
  )
}

export default UserList